#version 150
#extension GL_ARB_shader_bit_encoding : require

#moj_import <light.glsl>
#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec3 ChunkOffset;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec4 normal;

const uint k = 1103515245U;
vec3 uhash3(uvec3 x) {
    x = ((x >> 8U) ^ x.yzx) * k;
    x = ((x >> 8U) ^ x.yzx) * k;
    x = ((x >> 8U) ^ x.yzx) * k;
    
    return vec3(x) / float(0xffffffffU);
}

vec3 hash(vec3 f) { 
    return uhash3(floatBitsToUint(f));
}

vec3 offsetAt(vec3 pos) {
	vec3 offset = hash(mod(pos, 16.0));
	return (offset * 2.0 - 1.0) * 0.12;
}

vec3 interpolatedOffset(vec3 pos) {
	vec3 floorPos = floor(pos);
	vec3 fractPos = pos - floorPos;
	
	vec3 ooo = offsetAt(floorPos + vec3(0, 0, 0));
	vec3 ooi = offsetAt(floorPos + vec3(0, 0, 1));
	vec3 oio = offsetAt(floorPos + vec3(0, 1, 0));
	vec3 oii = offsetAt(floorPos + vec3(0, 1, 1));
	vec3 ioo = offsetAt(floorPos + vec3(1, 0, 0));
	vec3 ioi = offsetAt(floorPos + vec3(1, 0, 1));
	vec3 iio = offsetAt(floorPos + vec3(1, 1, 0));
	vec3 iii = offsetAt(floorPos + vec3(1, 1, 1));

	vec3 oo = mix(ooo, ooi, fractPos.z);
	vec3 oi = mix(oio, oii, fractPos.z);
	vec3 io = mix(ioo, ioi, fractPos.z);
	vec3 ii = mix(iio, iii, fractPos.z);
	
	vec3 o = mix(oo, oi, fractPos.y);
	vec3 i = mix(io, ii, fractPos.y);
	
	return mix(o, i, fractPos.x);
}

void main() {
    vec3 pos = Position + interpolatedOffset(Position) + ChunkOffset;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    vertexDistance = fog_distance(ModelViewMat, pos, FogShape);
    vertexColor = Color * minecraft_sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;
    normal = ProjMat * ModelViewMat * vec4(Normal, 0.0);
}